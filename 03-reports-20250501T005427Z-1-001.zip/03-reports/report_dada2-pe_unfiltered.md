# Tourmaline Report

View this HTML report with [Chrome](https://www.google.com/chrome/){target="_blank"} or [Firefox](https://www.mozilla.org/en-US/firefox/new/){target="_blank"} for best results.

To view the linked files below: 

* QZV (QIIME 2 visualization): click to download, then drag and drop in [https://view.qiime2.org](https://view.qiime2.org){target="_blank"}.
* TSV (tab-separated values): click to download, then open in Microsoft Excel or Tabview (command line tool).
* PDF (portable document format): click to open and view in new tab.
* Markdown and text: click to open and view in new tab.

Note: Downloaded files can be deleted after viewing, as they are already stored in your Tourmaline directory.

For information on Tourmaline outputs, visit [https://github.com/aomlomics/tourmaline](https://github.com/aomlomics/tourmaline){target="_blank"}.

---

## Metadata Summary

Markdown: [01-imported/metadata_summary.md](../01-imported/metadata_summary.md){target=_blank}

| Column name                        | Most common value         | Count   |
|:-----------------------------------|:--------------------------|:--------|
| sample_name                        | Influent_WWTP_7_10_23_MH1 | 1       |
| sample_name_water                  | Week1Aug2023              | 4       |
| taxon_id                           | (no values in column)     | --      |
| scientific_name                    | (no values in column)     | --      |
| host_subject_id                    | (no values in column)     | --      |
| physical_specimen_location         | (no values in column)     | --      |
| physical_specimen_remaining        | (no values in column)     | --      |
| collection_timestamp               | dry season                | 16      |
| latitude                           | (no values in column)     | --      |
| longitude                          | (no values in column)     | --      |
| lat_lon                            | (no values in column)     | --      |
| geo_loc_name                       | (no values in column)     | --      |
| env_biome                          | (no values in column)     | --      |
| env_feature                        | (no values in column)     | --      |
| env_material                       | (no values in column)     | --      |
| env_package                        | (no values in column)     | --      |
| alt                                | (no values in column)     | --      |
| depth                              | (no values in column)     | --      |
| elev                               | (no values in column)     | --      |
| description                        | (no values in column)     | --      |
| control_status                     | (no values in column)     | --      |
| sample_pairing                     | (no values in column)     | --      |
| sample_pairs                       | (no values in column)     | --      |
| esp_storage_carousel               | (no values in column)     | --      |
| sample_station                     | (no values in column)     | --      |
| sample_type                        | (no values in column)     | --      |
| collection_date                    | (no values in column)     | --      |
| site                               | (no values in column)     | --      |
| region                             | WetWeek1                  | 4       |
| time_started_filtering             | (no values in column)     | --      |
| filtration_duration_hhmmss         | (no values in column)     | --      |
| auv_avg_sample_depth_m             | (no values in column)     | --      |
| auv_range_sample_depth_m           | (no values in column)     | --      |
| large_depth_range                  | (no values in column)     | --      |
| sample_volume                      | (no values in column)     | --      |
| chlorophyll                        | (no values in column)     | --      |
| diss_oxygen                        | (no values in column)     | --      |
| down_par                           | (no values in column)     | --      |
| temp                               | (no values in column)     | --      |
| time_of_day                        | (no values in column)     | --      |
| qpcr_16s_total_cyano_cpr           | (no values in column)     | --      |
| total_cyanobacteria_qpcr_gc_per_ml | (no values in column)     | --      |
| qpcr_toxin_mcye_cpr                | (no values in column)     | --      |
| mcye_qpcr_gc_per_ml                | (no values in column)     | --      |
| filter_size                        | (no values in column)     | --      |
| concentration_ng_per_ul            | (no values in column)     | --      |
| volume_ul                          | (no values in column)     | --      |
| project_name                       | (no values in column)     | --      |
| investigation_type                 | R1                        | 8       |
| experimental_factor                | WetWeek1                  | 4       |
| experiment_design_description      | (no values in column)     | --      |
| target_gene                        | (no values in column)     | --      |
| target_subfragment                 | (no values in column)     | --      |
| pcr_primers                        | (no values in column)     | --      |
| pcr_primer_names                   | (no values in column)     | --      |
| seq_meth                           | (no values in column)     | --      |
| seq_platform                       | (no values in column)     | --      |
| seq_model                          | (no values in column)     | --      |
| seq_chemistry                      | (no values in column)     | --      |
| run_center                         | (no values in column)     | --      |
| run_date                           | (no values in column)     | --      |
| submitted_to_insdc                 | (no values in column)     | --      |


---

## Fastq Sequences Information

### Fastq Sequences per Sample

Markdown: [01-imported/fastq_counts_describe.md](../01-imported/fastq_counts_describe.md){target=_blank}

| Statistic (n=32)   |   Fastq sequences per sample |
|:-------------------|-----------------------------:|
| mean               |                      51454.7 |
| std                |                      13979.4 |
| min                |                      27325   |
| 25%                |                      41038   |
| 50%                |                      49611.5 |
| 75%                |                      59543.2 |
| max                |                      79169   |

### Visualization of Fastq Sequences

QZV: [01-imported/fastq_summary.qzv](../01-imported/fastq_summary.qzv){target=_blank}

---

## Representative Sequences Information

### Representative Sequences Properties Table

TSV: [02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties.tsv](../02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties.tsv){target=_blank}

Columns:

* featureid
* length - length (bp) not including gaps
* gaps - gaps (bp) in multiple sequence alignment
* outlier - outlier (True/False) determined by OD-seq
* taxonomy - domain level
* observations - total observations summed across all samples (unrarefied)
* log10(observations) - log base-10 of total observations

### Representative Sequences Properties Summary

Markdown: [02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties_describe.md](../02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties_describe.md){target=_blank}

| Statistic (n=2288)   |    length |      gaps |   observations |   log10(observations) |
|:---------------------|----------:|----------:|---------------:|----------------------:|
| mean                 | 252.981   |  97.0192  |        481.757 |              1.39408  |
| std                  |   2.37123 |   2.37123 |       4241.52  |              0.906644 |
| min                  | 169       |  70       |          1     |              0        |
| 25%                  | 253       |  97       |          5     |              0.69897  |
| 50%                  | 253       |  97       |         14     |              1.14613  |
| 75%                  | 253       |  97       |         88     |              1.94448  |
| max                  | 280       | 181       |     172578     |              5.23699  |

### Representative Sequences Properties Plot

PDF: [02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties.pdf](../02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_properties.pdf){target=_blank}


Plot elements:

* x: length (bp) not including gaps
* y: gaps (bp) in multiple sequence alignment
* color: taxonomy (domain)
* size: log10(observations)
* facets: outlier (True/False) determined by OD-seq

### Representative Sequences Rooted Tree

QZV: [02-output-dada2-pe-unfiltered/02-alignment-tree/rooted_tree.qzv](../02-output-dada2-pe-unfiltered/02-alignment-tree/rooted_tree.qzv){target=_blank}

### Representative Sequences to Filter

To filter, copy 02-output-{method}-{filter}/02-alignment-tree/repseqs_to_filter_outliers.tsv to 00-data/repseqs_to_filter_{method}.tsv, then run Snakemake in filtered mode. A file with unassigned repseqs is provided for reference; these sequences can be filtered by adding the term "unassigned" to "exclude_terms".

Outliers TSV: [02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_to_filter_outliers.tsv](../02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_to_filter_outliers.tsv){target=_blank}

Unassigned TSV: [02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_to_filter_unassigned.tsv](../02-output-dada2-pe-unfiltered/02-alignment-tree/repseqs_to_filter_unassigned.tsv){target=_blank}

### Visualization of Representative Sequences

QZV: [02-output-dada2-pe-unfiltered/00-table-repseqs/repseqs.qzv](../02-output-dada2-pe-unfiltered/00-table-repseqs/repseqs.qzv){target=_blank}

### Taxonomy Table

TSV: [02-output-dada2-pe-unfiltered/01-taxonomy/taxonomy.tsv](../02-output-dada2-pe-unfiltered/01-taxonomy/taxonomy.tsv){target=_blank}

### Visualization of Taxonomy

QZV: [02-output-dada2-pe-unfiltered/01-taxonomy/taxonomy.qzv](../02-output-dada2-pe-unfiltered/01-taxonomy/taxonomy.qzv){target=_blank}

### Taxonomy Reference Database

silva-138-99-515-806_q2-2021.2

### Predicted Amplicon Type

Text: [02-output-dada2-pe-unfiltered/00-table-repseqs/repseqs_amplicon_type.txt](../02-output-dada2-pe-unfiltered/00-table-repseqs/repseqs_amplicon_type.txt){target=_blank}

```
Amplicon locus: 16S/515f (80.0% of sequences start with TACG)
```

---

## Observation Table Information

### Table Summary: Samples

Text: [02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary_samples.txt](../02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary_samples.txt){target=_blank}

```
Num samples: 32
Num features: 2288
Total count: 1102259
Table density (fraction of non-zero values): 0.121

Counts/sample summary:
 Min: 0
 Max: 57516
 Median: 30385
 Mean: 34445.594
 Std. dev.: 12903.280
 Sample Metadata Categories: None provided
 Observation Metadata Categories: None provided
```

### Table Summary: Features

Text: [02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary_features.txt](../02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary_features.txt){target=_blank}

```
Num samples: 32
Num features: 2288
Total count: 1102259
Table density (fraction of non-zero values): 0.121

Counts/feature summary:
 Min: 1
 Max: 172578
 Median: 14
 Mean: 481.757
 Std. dev.: 4240.593
 Sample Metadata Categories: None provided
 Observation Metadata Categories: None provided
```

### Visualization of Table Summary

QZV: [02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary.qzv](../02-output-dada2-pe-unfiltered/00-table-repseqs/table_summary.qzv){target=_blank}

---

## Taxonomic Diversity Results

### Taxonomy Barplot

QZV: [02-output-dada2-pe-unfiltered/01-taxonomy/taxa_barplot.qzv](../02-output-dada2-pe-unfiltered/01-taxonomy/taxa_barplot.qzv){target=_blank}

---

## Alpha Diversity Results

### Alpha Rarefaction

QZV: [02-output-dada2-pe-unfiltered/03-alpha-diversity/alpha_rarefaction.qzv](../02-output-dada2-pe-unfiltered/03-alpha-diversity/alpha_rarefaction.qzv){target=_blank}

### Alpha Group Significance

Evenness QZV: [02-output-dada2-pe-unfiltered/03-alpha-diversity/evenness_group_significance.qzv](../02-output-dada2-pe-unfiltered/03-alpha-diversity/evenness_group_significance.qzv){target=_blank}

Faith PD QZV: [02-output-dada2-pe-unfiltered/03-alpha-diversity/faith_pd_group_significance.qzv](../02-output-dada2-pe-unfiltered/03-alpha-diversity/faith_pd_group_significance.qzv){target=_blank}

Observed features QZV: [02-output-dada2-pe-unfiltered/03-alpha-diversity/observed_features_group_significance.qzv](../02-output-dada2-pe-unfiltered/03-alpha-diversity/observed_features_group_significance.qzv){target=_blank}

Shannon QZV: [02-output-dada2-pe-unfiltered/03-alpha-diversity/shannon_group_significance.qzv](../02-output-dada2-pe-unfiltered/03-alpha-diversity/shannon_group_significance.qzv){target=_blank}

---

## Beta Diversity Results

### PCoA Emperor Plots

Bray-Curtis QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/bray_curtis_emperor.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/bray_curtis_emperor.qzv){target=_blank}

Jaccard QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/jaccard_emperor.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/jaccard_emperor.qzv){target=_blank}

Weighted UniFrac QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/weighted_unifrac_emperor.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/weighted_unifrac_emperor.qzv){target=_blank}

Unweighted UniFrac QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/unweighted_unifrac_emperor.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/unweighted_unifrac_emperor.qzv){target=_blank}

DEICODE Biplot QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/deicode_biplot_emperor.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/deicode_biplot_emperor.qzv){target=_blank}

### Beta Group Significance

Bray-Curtis QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/bray_curtis_group_significance.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/bray_curtis_group_significance.qzv){target=_blank}

Jaccard QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/jaccard_group_significance.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/jaccard_group_significance.qzv){target=_blank}

Weighted UniFrac QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/weighted_unifrac_group_significance.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/weighted_unifrac_group_significance.qzv){target=_blank}

Unweighted UniFrac QZV: [02-output-dada2-pe-unfiltered/04-beta-diversity/unweighted_unifrac_group_significance.qzv](../02-output-dada2-pe-unfiltered/04-beta-diversity/unweighted_unifrac_group_significance.qzv){target=_blank}

---

## Tourmaline Config File

YAML: [config.yaml](../config.yaml){target=_blank}

```
# config.yaml - configuration file for the Tourmaline Snakemake workflow
# Compatable with qiime2-2023.5
# User MUST edit these parameters before running their own data.
# Detailed instructions: https://github.com/aomlomics/tourmaline/wiki.

# METADATA FILE

# Metadata file must be named as follows (or use symbolic link):
# - 00-data/metadata.tsv

# Standardization is recommended through use of MIxS/MIMARKS (https://gensc.org/mixs/) column headers, for example:
# - submitted_to_insdc: {boolean}
# - investigation_type: [eukaryote|bacteria_archaea|plasmid|virus|organelle|metagenome|metatranscriptome|mimarks-survey|mimarks-specimen|misag|mimag|miuvig]
# - project_name: {text}
# - experimental_factor (text or EFO and/or OBI): {termLabel} {[termID]}|{text}
# - lat_lon (decimal degrees): {float} {float}

# FASTQ DATA (choose one option)

# Option 1 - if you want to start from manifest files and import per-sample fastq sequences,
# Name your manifest file(s) as follows (or use symbolic links):
# - paired-end sequences: 00-data/manifest_pe.csv
# - single-end sequences: 00-data/manifest_se.csv

# Option 2 - if your fastq sequences are already archived in qza format,
# Name your qza file(s) as follows (or use symbolic links):
# - paired-end sequences: 01-imported/fastq_pe.qza
# - single-end sequences: 01-imported/fastq_se.qza

# REFERENCE DATABASE (choose one option)

# Option 1 - if your reference database is not yet imported, 
# Name your reference fna and tsv files as follows (or use symbolic links):
# - reference sequences: 00-data/refseqs.fna
# - reference taxonomy: 00-data/reftax.tsv

# Option 2 - if your reference database is already archived in qza format,
# Name your your qza files as follows (or use symbolic links):
# - reference sequences: 01-imported/refseqs.qza
# - reference taxonomy: 01-imported/reftax.qza

# Provide a descriptive name for the reference database used, no spaces (e.g., original file name, source and version)
database_name: silva-138-99-515-806_q2-2021.2

# DENOISE

# DADA2 PAIRED-END
# For more info run: qiime dada2 denoise-paired --help

dada2pe_trunc_len_f: 0
dada2pe_trunc_len_r: 0
dada2pe_trim_left_f: 0
dada2pe_trim_left_r: 0
dada2pe_max_ee_f: 2
dada2pe_max_ee_r: 2
dada2pe_trunc_q: 2
dada2pe_pooling_method: independent
dada2pe_chimera_method: consensus
dada2pe_min_fold_parent_over_abundance: 1
dada2pe_n_reads_learn: 1000000
dada2pe_hashed_feature_ids: --p-hashed-feature-ids

# DADA2 SINGLE-END
# For more info run: qiime dada2 denoise-single --help

dada2se_trunc_len: 240
dada2se_trim_left: 0
dada2se_max_ee: 2
dada2se_trunc_q: 2
dada2se_pooling_method: independent
dada2se_chimera_method: consensus
dada2se_min_fold_parent_over_abundance: 1
dada2se_n_reads_learn: 1000000
dada2se_hashed_feature_ids: --p-hashed-feature-ids

# DEBLUR SINGLE-END
# For more info run: qiime deblur denoise-other --help

deblur_trim_length: 240
deblur_sample_stats: --p-sample-stats
deblur_mean_error: 0.005
deblur_indel_prob: 0.01
deblur_indel_max: 3
deblur_min_reads: 10
deblur_min_size: 2
deblur_hashed_feature_ids: --p-hashed-feature-ids

# TAXONOMIC CLASSIFICATION

# Taxonomic classification of the representative sequences.
# - method: choose from: naive-bayes, consensus-blast, consensus-vsearch
# - parameters: add arbitrary parameters or at least one parameter; see "qiime feature-classifier COMMAND --help"
# For more info run: qiime feature-classifier [fit-classifier-naive-bayes|classify-sklearn|classify-consensus-blast|classify-consensus-vsearch] --help
classify_method: consensus-vsearch
classify_parameters: --verbose

# Table of feature counts per sample collapsed by chosen taxonomic level.
# taxa_level - taxonomic level at which the features should be collapsed. Default 7
# For more info run: qiime taxa collapse --help
classify_taxalevel: 7

# MULTIPLE SEQUENCE ALIGNMENT

# Multiple sequence alignment of the representative sequences.
# - method: choose from: muscle v5, clustalo, mafft
# - muscle_iters: number of refinement iterations (integer, default 100)
# For more info run: muscle, clustalo --help, qiime alignment [mafft|mask] --help

alignment_method: muscle
alignment_muscle_iters: 50

# OUTLIER DETECTION

# Representative sequence outlier detection using odseq.
# - distance_metric: choose from: linear, affine
# - bootstrap_replicates: number of bootstrap replicates (integer)
# - threshold: probability to be at right of the bootstrap scores distribution (float)
# For more info see: https://www.bioconductor.org/packages/release/bioc/html/odseq.html

odseq_distance_metric: linear
odseq_bootstrap_replicates: 100
odseq_threshold: 0.025

# SUBSAMPLING (RAREFACTION)

# Subsample (rarefy) data to have an even number of observations per sample.
# - core_sampling_depth: subsampling depth for core diversity analyses
# - alpha_max_depth: maximum subsampling depth for alpha diversity rarefaction analysis

core_sampling_depth: 500
alpha_max_depth: 500

# BETA GROUP SIGNIFICANCE

# Statistical test for difference between samples grouped by a metadata variable (column).
# - column: metadata column to test beta group significance; this column must appear in the metadata file 00-data/metadata.tsv
# - method: choose from: permanova, anosim, permdisp
# - pairwise: choose from: --p-no-pairwise, --p-pairwise (can be very slow)

beta_group_column: region
beta_group_method: permanova
beta_group_pairwise: --p-pairwise

# DEICODE BETA DIVERSITY

# Robust Aitchison PCA (and biplot ordination) with automatically estimated underlying low-rank structure.
# Parameters are set to recommended defaults:
# - min_sample_count: minimum sum cutoff of samples across all features
# - min_feature_count: minimum sum cufoff of features across all samples
# - min_feature_frequency: minimum percentage of samples a feature must appear with value greater than zero
# - max_iterations: number of iterations to optimize the solution
# - num_features: number of most important features (arrows) to display in the biplot ordination
# For more info run: qiime deicode auto-rpca --help

deicode_min_sample_count: 500
deicode_min_feature_count: 10
deicode_min_feature_frequency: 0
deicode_max_iterations: 5
deicode_num_features: 5

# REPORT THEME

# Report theme for html version.
# Choose from: github, gothic, newsprint, night, pixyll, whitey.

report_theme: github

# FILTERING

# Filtering is implemented by filtering commands only, eg "snakemake dada2_pe_report_filtered", and is applied to each of
# representative sequences, taxonomy, and feature table.

# FILTER SAMPLES BY ID
# The file of sample IDs to be removed must have the sample IDs in the 1st column with a header line. Any number of additional columns can be added.
# The file must be named 00-data/samples_to_filter_{method}.tsv, where method is dada2-pe, dada2-se, or deblur-se.
# For more info run: qiime feature-table filter-samples --help
# TO SKIP FILTERING BY SAMPLE ID: provide a file with only headers (default) or don't run filtering commands.

# FILTER SAMPLES BY METADATA
# Samples can be removed or retained based on their metadata, using SQLite WHERE-clause syntax inside double quotes.
# For more info run: qiime feature-table filter-samples --help
# TO SKIP FILTERING BY SAMPLE METADATA: provide "none" (default) or don't run filtering commands.
# EXAMPLE: "[region]='Open Water'"
metadata_filter: none

# FILTER BY FEATURE ID
# The file of feature IDs to be filtered must have a header line with two columns: 1. "featureid", 2. anything.
# The file must be named 00-data/repseqs_to_filter_{method}.tsv, where method is dada2-pe, dada2-se, or deblur-se.
# If filtering outliers, just copy 02-output-{method}-{filter}/02-alignment-tree/repseqs_to_filter_outliers.tsv to the above filename.
# Add any additional feature IDs to be filtered (no duplicates allowed).
# For more info run: qiime feature-table [filter-seqs|filter-features] --help
# TO SKIP FILTERING BY FEATURE ID: provide only nonsense feature IDs in the above files (default) or don't run filtering commands.

# FILTER BY TAXONOMY
# Features with taxonomy containing these terms will be filtered.
# Separate terms with commas (e.g., mitochondria,chloroplast,eukaryota,unassigned).
# Terms are not case-sensitive.
# For more info run: qiime taxa filter-seqs --help
# TO SKIP FILTERING BY TAXONOMY: provide a nonsense term or don't run filtering commands.

exclude_terms: eukaryota,archaea,mitochondria,chloroplast,unassigned

# FILTER BY LENGTH
# Set minimum and maximum sequence lengths to filter representative sequences by.
# Limits are inclusive, ie, greater than or equal to minimum, less than or equal to maximum.
# For more info run: qiime feature-table filter-seqs --help
# TO SKIP FILTERING BY LENGTH: set values to extreme values, eg (0, 10000) or don't run filtering commands.

repseq_min_length: 0
repseq_max_length: 260

# FILTER BY ABUNDANCE & PREVALENCE
# Set minimum abundance/prevalence limits for filtering.
# Values are floats range(0,1)
# Limit is inclusive, ie, greater than or equal to minimum. Samples with frequency of 0 after filtering will also be removed.
# For more info run: qiime feature-table filter-features-conditionally --help
# TO SKIP FILTERING BY ABUNDANCE/PREVALENCE: set values to 0 or don't run filtering commands.

repseq_min_abundance: 0.01
repseq_min_prevalence: 0.1

# THREADS

# Max number of threads for individual rules.
# Threads used will be the lower of this and snakemake parameter --cores.
# Parameter other_threads is used for all other rules, regardless if they can use multiple threads, 
# because it prevents multiple rules from running simultaneously with --cores >1.

dada2pe_threads: 8
dada2se_threads: 8
deblur_threads: 8
alignment_threads: 8
feature_classifier_threads: 8
phylogeny_fasttree_threads: 8
diversity_core_metrics_phylogenetic_threads: 8
other_threads: 8
```
